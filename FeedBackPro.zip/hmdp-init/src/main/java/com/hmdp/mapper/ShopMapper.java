package com.hmdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hmdp.entity.Shop;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface ShopMapper extends BaseMapper<Shop> {

}
