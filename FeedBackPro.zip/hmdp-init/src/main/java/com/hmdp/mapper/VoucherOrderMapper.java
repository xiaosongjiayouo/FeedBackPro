package com.hmdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hmdp.entity.VoucherOrder;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface VoucherOrderMapper extends BaseMapper<VoucherOrder> {

}
