package com.hmdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hmdp.entity.ShopType;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface ShopTypeMapper extends BaseMapper<ShopType> {

}
