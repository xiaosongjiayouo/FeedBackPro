package com.hmdp.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hmdp.entity.Follow;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface FollowMapper extends BaseMapper<Follow> {

}
