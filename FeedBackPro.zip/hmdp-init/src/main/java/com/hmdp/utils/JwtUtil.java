package com.hmdp.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Map;

public class JwtUtil {
    /**
     * 生成jwt
     * 使用Hs256算法, 私匙使用固定秘钥
     *
     * @param claims    设置的信息
     * @return
     */
    // 生成访问Token
    public static String generateAccessToken(Map<String, Object> claims) {
        return createJWT(claims, 7200000L);
    }

    // 生成刷新Token
    public static String generateRefreshToken(Map<String, Object> claims) {
        return createJWT(claims, 72000000L);
    }

    public static String createJWT(Map<String, Object> claims, Long expiration) {
        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiration * 1000))
                .signWith( SignatureAlgorithm.HS256,"itcast")
                .compact();
    }

    /**
     * Token解密
     *
     * @param token     加密后的token
     * @return
     */
    public static Claims parseJWT(String token) {
        // 得到DefaultJwtParser
        Claims claims = Jwts.parser()
                // 设置签名的秘钥
                .setSigningKey("itcast")
                // 设置需要解析的jwt
                .parseClaimsJws(token).getBody();
        return claims;
    }

    // 验证Token是否过期
    public boolean isTokenExpired(String token) {
        try {
            return parseJWT(token).getExpiration().before(new Date());
        } catch (Exception e) {
            return true;
        }
    }

    // 刷新Token
    public String refreshToken(String refreshToken) {
        Claims claims = parseJWT(refreshToken);
        claims.put("refreshTime", new Date());
        return generateAccessToken(claims);
    }
}
