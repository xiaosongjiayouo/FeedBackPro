package com.hmdp.interceptor;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.hmdp.dto.UserDTO;
import com.hmdp.utils.JwtUtil;
import com.hmdp.utils.RedisConstants;
import com.hmdp.utils.UserHolder;
import io.jsonwebtoken.Claims;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 刷新令牌拦截器
 */
public class RefreshTokenInterceptor implements HandlerInterceptor {
    private final StringRedisTemplate stringRedisTemplate;

    public RefreshTokenInterceptor(StringRedisTemplate stringRedisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //从请求头中获取token
        String token = request.getHeader("authorization");
        if (StringUtils.isEmpty(token)) {
            //不存在token
            return true;
        }
        //从redis中获取用户
        Map<Object, Object> userMap =
                stringRedisTemplate.opsForHash()
                        .entries(RedisConstants.LOGIN_USER_KEY + token);
        //用户不存在
        if (userMap.isEmpty()) {
            return true;
        }
//        // JWT
//        // 解析Token
//        Claims claims = JwtUtil.parseJWT(token);
//        // 检查是否需要刷新(在过期前30分钟内)
//        if (shouldRefreshToken(claims)) {
//            Long userId = Long.valueOf(claims.get("id").toString());
//            String newAccessToken = refreshAccessToken(userId);
//            if (newAccessToken != null) {
//                // 将新Token放入响应头
//                response.setHeader("New-Access-Token", newAccessToken);
//            }
//        }
        //hash转UserDTO存入ThreadLocal
        UserHolder.saveUser(BeanUtil.fillBeanWithMap(userMap, new UserDTO(), false));
        //token续命
        stringRedisTemplate.expire(RedisConstants.LOGIN_USER_KEY + token, RedisConstants.LOGIN_USER_TTL, TimeUnit.MINUTES);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserHolder.removeUser();
    }


    private boolean shouldRefreshToken(Claims claims) {
        Date expiration = claims.getExpiration();
        long currentTime = System.currentTimeMillis();
        return (expiration.getTime() - currentTime) < (30 * 60 * 1000); // 30分钟内过期
    }
    private String refreshAccessToken(Long userId) {
        String refreshToken = stringRedisTemplate.opsForValue().get("user:refresh:" + userId);
        if (refreshToken != null) {
            try {
                Claims claims = JwtUtil.parseJWT(refreshToken);
                return JwtUtil.generateAccessToken(claims);
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
}
