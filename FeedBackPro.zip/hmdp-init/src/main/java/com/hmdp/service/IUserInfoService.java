package com.hmdp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hmdp.entity.UserInfo;

/**
 * <p>
 *  服务类
 * </p>
 */
public interface IUserInfoService extends IService<UserInfo> {

}
