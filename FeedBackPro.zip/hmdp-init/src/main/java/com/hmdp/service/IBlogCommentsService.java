package com.hmdp.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hmdp.entity.BlogComments;

/**
 * <p>
 *  服务类
 * </p>
 */
public interface IBlogCommentsService extends IService<BlogComments> {

}
